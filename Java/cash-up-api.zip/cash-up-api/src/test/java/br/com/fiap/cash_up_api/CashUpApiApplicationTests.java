package br.com.fiap.cash_up_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CashUpApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
