package br.com.fiap.cash_up_api.model;

public enum TypeAccount {
    CORRENTE ,
    POUPANCA ,
    SALARIO ;
    
}
