interface Assets {
    id: number,
    name: string,
    icon: string
    price: number,
    quantity: number
}